package mainparcial1;

public class PublicacionDuplicadaException extends Exception {
    public PublicacionDuplicadaException(String mensaje) {
        super(mensaje);
    }
}