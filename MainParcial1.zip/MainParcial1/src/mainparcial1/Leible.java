package mainparcial1;

public interface Leible {
    void leer();
}