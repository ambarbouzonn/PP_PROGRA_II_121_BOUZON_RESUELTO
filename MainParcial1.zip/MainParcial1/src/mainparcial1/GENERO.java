package mainparcial1;

public enum GENERO {
    FICCION, NO_FICCION, CIENCIA, HISTORIA;
}
